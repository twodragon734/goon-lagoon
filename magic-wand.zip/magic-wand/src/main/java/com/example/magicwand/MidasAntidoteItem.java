package com.example.magicwand;

import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;

/** The only cure for the Midas Touch. Drinkable, gives you a glass bottle back. */
public class MidasAntidoteItem extends Item {
    public MidasAntidoteItem(Settings settings) {
        super(settings);
    }

    @Override
    public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
        ItemStack result = super.finishUsing(stack, world, user); // handles drinking + glass bottle

        if (world instanceof ServerWorld sw && user instanceof ServerPlayerEntity player) {
            MidasCurse.cure(player);
            sw.spawnParticles(ParticleTypes.HAPPY_VILLAGER, player.getX(), player.getY() + 1.0, player.getZ(),
                    30, 0.4, 0.7, 0.4, 0.1);
        }
        return result;
    }
}
