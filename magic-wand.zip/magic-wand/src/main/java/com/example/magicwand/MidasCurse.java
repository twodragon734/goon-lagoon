package com.example.magicwand;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.BlockPos;

import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * The Midas Touch curse. A cursed player turns whatever they touch into gold:
 *  - blocks they punch or right-click become gold blocks,
 *  - mobs they punch become gold blocks,
 *  - the item in their hand becomes gold blocks.
 * Only drinking a Midas Antidote lifts it. The curse is saved in the world folder.
 */
public final class MidasCurse {
    private MidasCurse() {}

    private static final Gson GSON = new Gson();
    private static final Type LIST_TYPE = new TypeToken<List<String>>() {}.getType();

    private static final Set<UUID> CURSED = new HashSet<>();
    private static Path file;

    public static boolean isCursed(PlayerEntity player) {
        return CURSED.contains(player.getUuid());
    }

    public static void curse(PlayerEntity player) {
        CURSED.add(player.getUuid());
        save();
        player.sendMessage(Text.literal("The Midas Touch has cursed you! Everything you touch turns to gold. "
                + "Only a Midas Antidote can free you.").formatted(Formatting.GOLD), false);
    }

    public static void cure(PlayerEntity player) {
        if (CURSED.remove(player.getUuid())) {
            save();
            player.sendMessage(Text.literal("The golden curse fades away. You are free!")
                    .formatted(Formatting.YELLOW), false);
        } else {
            player.sendMessage(Text.literal("You feel purified, but you were not cursed.")
                    .formatted(Formatting.GRAY), true);
        }
    }

    /** Items a cursed player can still hold without them turning to gold. */
    private static boolean exempt(ItemStack stack) {
        return stack.isOf(Items.GOLD_BLOCK)
                || stack.isOf(MagicWandMod.MIDAS_ANTIDOTE)
                || stack.isOf(MagicWandMod.MIDAS_SCROLL);
    }

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            file = server.getSavePath(WorldSavePath.ROOT).resolve("magicwand_midas.json");
            load();
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            save();
            CURSED.clear();
        });

        // Every tick: the items in a cursed player's hands turn to gold blocks.
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (!isCursed(p)) continue;

                for (Hand hand : Hand.values()) {
                    ItemStack held = p.getStackInHand(hand);
                    if (held.isEmpty() || exempt(held)) continue;
                    p.setStackInHand(hand, new ItemStack(Items.GOLD_BLOCK, Math.min(64, held.getCount())));
                    sparkle((ServerWorld) p.getWorld(), p.getX(), p.getY() + 1.2, p.getZ());
                }

                if (server.getTicks() % 10 == 0) { // a faint golden glow so others can see the curse
                    ((ServerWorld) p.getWorld()).spawnParticles(ParticleTypes.END_ROD,
                            p.getX(), p.getY() + 1.0, p.getZ(), 2, 0.3, 0.6, 0.3, 0.01);
                }
            }
        });

        // Punching a block turns it to gold instead of breaking it.
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (!(world instanceof ServerWorld sw) || !isCursed(player)) {
                return ActionResult.PASS;
            }
            touchBlock(sw, pos, player);
            return ActionResult.SUCCESS;
        });

        // Right-clicking a block turns it to gold instead of using it.
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!(world instanceof ServerWorld sw) || !isCursed(player)) {
                return ActionResult.PASS;
            }
            ItemStack held = player.getStackInHand(hand);
            if (held.isOf(MagicWandMod.MIDAS_ANTIDOTE) || held.isOf(MagicWandMod.MIDAS_SCROLL)) {
                return ActionResult.PASS; // let them drink the cure
            }
            touchBlock(sw, hit.getBlockPos(), player);
            return ActionResult.SUCCESS;
        });

        // Punching a mob turns it into a gold block.
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!(world instanceof ServerWorld sw) || !isCursed(player)) {
                return ActionResult.PASS;
            }
            if (entity instanceof LivingEntity && !(entity instanceof PlayerEntity)) {
                BlockPos at = entity.getBlockPos();
                BlockState there = sw.getBlockState(at);
                entity.discard();
                if (there.isAir() || there.isReplaceable()) {
                    sw.setBlockState(at, Blocks.GOLD_BLOCK.getDefaultState());
                } else {
                    sw.spawnEntity(new ItemEntity(sw, entity.getX(), entity.getY(), entity.getZ(),
                            new ItemStack(Items.GOLD_BLOCK)));
                }
                sparkle(sw, entity.getX(), entity.getY() + 0.5, entity.getZ());
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });
    }

    private static void touchBlock(ServerWorld world, BlockPos pos, PlayerEntity player) {
        BlockState state = world.getBlockState(pos);
        if (state.isAir() || state.isOf(Blocks.GOLD_BLOCK)) return;
        if (state.getHardness(world, pos) < 0) return; // bedrock and friends are safe

        if (world.getBlockEntity(pos) != null) {
            world.breakBlock(pos, true, player); // chests etc. drop their contents first
        }
        world.setBlockState(pos, Blocks.GOLD_BLOCK.getDefaultState());
        sparkle(world, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
    }

    private static void sparkle(ServerWorld world, double x, double y, double z) {
        world.spawnParticles(ParticleTypes.END_ROD, x, y, z, 12, 0.4, 0.4, 0.4, 0.05);
        world.playSound(null, BlockPos.ofFloored(x, y, z), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME,
                SoundCategory.PLAYERS, 0.8F, 1.6F);
    }

    private static void load() {
        CURSED.clear();
        try {
            if (file != null && Files.exists(file)) {
                List<String> ids = GSON.fromJson(Files.readString(file), LIST_TYPE);
                if (ids != null) {
                    for (String id : ids) CURSED.add(UUID.fromString(id));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void save() {
        if (file == null) return;
        try {
            List<String> ids = new ArrayList<>();
            for (UUID id : CURSED) ids.add(id.toString());
            Files.writeString(file, GSON.toJson(ids));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
