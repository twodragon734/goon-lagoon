package com.example.magicwand;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Property;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The Crush Wand.
 *  Right-click:         falling dripstone (stalactites) where you aim.
 *  Sneak + right-click: falling anvils where you aim.
 * The blocks fall from above the target, hurt what they land on, then shatter (no mess left behind).
 * The Steady Aim upgrade shrinks the landing area: 7x7, then 5x5, then 3x3.
 */
public class CrushWandItem extends Item {
    // ---- Tweak these to taste (20 ticks = 1 second) ----
    private static final double RANGE = 40.0;            // how far you can aim
    private static final int DROP_HEIGHT = 12;           // how high up the blocks start (if there is room)
    private static final int DRIPSTONE_COOLDOWN_TICKS = 60;
    private static final int ANVIL_COOLDOWN_TICKS = 100;
    private static final int DRIPSTONE_MANA_COST = 35;
    private static final int ANVIL_MANA_COST = 50;
    private static final int DRIPSTONE_BASE_COUNT = 4;   // +2 per Barrage level
    private static final int ANVIL_BASE_COUNT = 1;       // +1 per Barrage level
    private static final int BASE_HALF_WIDTH = 3;        // 3 = a 7x7 area; Steady Aim lowers it by 1 per level (min 1 = 3x3)
    private static final float DAMAGE_PER_BLOCK = 2.0F;  // damage per block fallen (same as vanilla)
    private static final int MAX_DAMAGE = 40;            // damage cap (same as vanilla)
    private static final double AIM_ASSIST_RADIUS = 3.0;   // hostile mobs this close to your crosshair get targeted
    private static final int LEAD_TICKS = 22;               // aim ahead of walking mobs (the blocks take about this long to fall)
    // -----------------------------------------------------

    public CrushWandItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        if (!(world instanceof ServerWorld sw)) {
            return ActionResult.SUCCESS;
        }
        ItemStack stack = user.getStackInHand(hand);
        boolean anvils = user.isSneaking();

        String required = anvils ? "anvil_drop" : "stalactite_fall";
        if (UpgradeManager.level(user, required) < 1) {
            UpgradeManager.sendLocked(user, required);
            return ActionResult.FAIL;
        }

        int cost = anvils ? ANVIL_MANA_COST : DRIPSTONE_MANA_COST;
        if (!ManaManager.tryUse(user, cost)) {
            return ActionResult.FAIL;
        }

        WandUtil.Aim aim = WandUtil.aim(sw, user, RANGE, false);

        // Step back off the surface you hit, so a wall or cliff face targets the air in front of it
        // (not the solid block behind it, which put everything one block off).
        Vec3d look = user.getRotationVec(1.0F);
        Vec3d target = aim.entity() != null ? aim.point() : aim.point().subtract(look.multiply(0.05));

        // Lock onto a hostile mob near the crosshair, and aim a little ahead if it is walking.
        target = snapToMob(sw, user, aim, target);
        WandUtil.trail(sw, user.getEyePos().add(0, -0.2, 0), target, ParticleTypes.CRIT);

        int barrage = UpgradeManager.level(user, "barrage");
        int half = Math.max(1, BASE_HALF_WIDTH - UpgradeManager.level(user, "steady_aim"));

        int dropped;
        if (anvils) {
            dropped = rain(sw, user, target, Blocks.ANVIL.getDefaultState(), ANVIL_BASE_COUNT + barrage, half);
        } else {
            dropped = rain(sw, user, target, pointedDown(), DRIPSTONE_BASE_COUNT + 2 * barrage, half);
        }

        if (dropped == 0) {
            ManaManager.refund(user, cost); // nothing could fall there (no room above), so no mana lost
            return ActionResult.FAIL;
        }

        sw.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_EVOKER_CAST_SPELL,
                SoundCategory.PLAYERS, 1.0F, 0.6F);
        user.getItemCooldownManager().set(stack, anvils ? ANVIL_COOLDOWN_TICKS : DRIPSTONE_COOLDOWN_TICKS);
        return ActionResult.SUCCESS;
    }

    /** If you aimed at a mob (or a hostile one is near your crosshair), target it, leading it if it moves. */
    private Vec3d snapToMob(ServerWorld world, PlayerEntity user, WandUtil.Aim aim, Vec3d target) {
        LivingEntity best = null;

        if (aim.entity() instanceof LivingEntity living && living != user) {
            best = living; // you pointed straight at it
        } else {
            double bestDist = AIM_ASSIST_RADIUS * AIM_ASSIST_RADIUS;
            Box area = new Box(target, target).expand(AIM_ASSIST_RADIUS);
            for (LivingEntity e : world.getEntitiesByClass(LivingEntity.class, area,
                    x -> x != user && x.isAlive() && !x.isSpectator() && x instanceof Monster)) {
                double d = e.getPos().add(0, e.getHeight() / 2.0, 0).squaredDistanceTo(target);
                if (d < bestDist) {
                    bestDist = d;
                    best = e;
                }
            }
        }

        if (best == null) {
            return target;
        }
        Vec3d pos = best.getPos();
        if (!(best instanceof PlayerEntity)) {
            Vec3d v = best.getVelocity();
            pos = pos.add(v.x * LEAD_TICKS, 0, v.z * LEAD_TICKS);
        }
        return pos;
    }

    /**
     * Drops up to `count` copies of the block from above the target area, each in its own column.
     * The area is (2*half+1) wide: the column you aim at always gets one first, the rest are picked at random.
     * Returns how many actually started falling.
     */
    private int rain(ServerWorld world, PlayerEntity user, Vec3d target, BlockState state, int count, int half) {
        BlockPos center = BlockPos.ofFloored(target);

        List<int[]> cells = new ArrayList<>();
        for (int dx = -half; dx <= half; dx++) {
            for (int dz = -half; dz <= half; dz++) {
                if (dx != 0 || dz != 0) cells.add(new int[] {dx, dz});
            }
        }
        Collections.shuffle(cells);
        cells.add(0, new int[] {0, 0}); // the exact block you aimed at goes first

        int dropped = 0;
        int n = Math.min(count, cells.size());
        for (int i = 0; i < n; i++) {
            int x = center.getX() + cells.get(i)[0];
            int z = center.getZ() + cells.get(i)[1];

            // Stay away from yourself so you don't crush your own head.
            if (Math.hypot(x + 0.5 - user.getX(), z + 0.5 - user.getZ()) < 2.0) continue;

            // Start at the aim height, step up out of any solid block, then see how much free air is above.
            BlockPos start = new BlockPos(x, center.getY(), z);
            int guard = 0;
            while (!world.getBlockState(start).isAir() && guard++ < 6) {
                start = start.up();
            }
            if (!world.getBlockState(start).isAir()) continue;

            int free = 0;
            while (free < DROP_HEIGHT && world.getBlockState(start.up(free + 1)).isAir()) {
                free++;
            }
            BlockPos spawn = start.up(free);

            FallingBlockEntity falling = FallingBlockEntity.spawnFromBlock(world, spawn, state);
            falling.setHurtEntities(DAMAGE_PER_BLOCK, MAX_DAMAGE);
            falling.setDestroyedOnLanding(); // shatters when it lands, so nothing is left behind
            dropped++;

            // Mark the landing spot so you can see the area you hit
            world.spawnParticles(ParticleTypes.CRIT, x + 0.5, start.getY() + 0.1, z + 0.5, 4, 0.25, 0.05, 0.25, 0.02);
            world.spawnParticles(ParticleTypes.LARGE_SMOKE, x + 0.5, start.getY() + 0.2, z + 0.5, 2, 0.2, 0.1, 0.2, 0.01);
        }
        return dropped;
    }

    /** A pointed dripstone with its tip facing down, found by property name so it works across versions. */
    private static BlockState pointedDown() {
        BlockState state = Blocks.POINTED_DRIPSTONE.getDefaultState();
        for (Property<?> prop : state.getProperties()) {
            if (prop.getName().equals("vertical_direction")) {
                state = withParsed(state, prop, "down");
            }
        }
        return state;
    }

    private static <T extends Comparable<T>> BlockState withParsed(BlockState state, Property<T> prop, String value) {
        return prop.parse(value).map(v -> state.with(prop, v)).orElse(state);
    }
}
