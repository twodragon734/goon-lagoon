package com.example.magicwand;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/** The cursed red scroll found in the shrine. Reading it curses you with the Midas Touch. */
public class MidasScrollItem extends Item {
    public MidasScrollItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        if (!(world instanceof ServerWorld sw)) {
            return ActionResult.SUCCESS;
        }
        if (MidasCurse.isCursed(user)) {
            user.sendMessage(Text.literal("You are already touched by Midas.").formatted(Formatting.YELLOW), true);
            return ActionResult.FAIL;
        }

        ItemStack stack = user.getStackInHand(hand);
        MidasCurse.curse(user);
        sw.spawnParticles(ParticleTypes.END_ROD, user.getX(), user.getY() + 1.0, user.getZ(),
                60, 0.5, 0.9, 0.5, 0.15);
        sw.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_ELDER_GUARDIAN_CURSE,
                SoundCategory.PLAYERS, 1.0F, 1.0F);
        stack.decrementUnlessCreative(1, user); // the scroll crumbles to dust
        return ActionResult.SUCCESS;
    }
}
